
#include "../include/TreeServer.h"

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>  


#define MAX_CHAR_COMMAND 256 
/**  
* \brief Realiza 
**/ 
void reader(char *FileName);

