#include "../include/Reader.h"  

/*
Função main in 
invoca a função de leitura  
*/
int main(int argc, char *argv[]){ 
    
    reader(argv[1]);
    return 0; 
}   